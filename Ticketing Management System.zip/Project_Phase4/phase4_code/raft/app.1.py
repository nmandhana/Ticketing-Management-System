from __future__ import print_function
from __future__ import division
from builtins import str
from builtins import range
#from typing_extensions import Self
from past.utils import old_div
from builtins import object
import time
import zmq
import multiprocessing
import json
import random
import threading
from queue import Queue, Empty

class MessageType(object):
	RequestVotes = 0
	RequestVoteResponse = 1
	Heartbeat = 2
	Acknowledge = 3
	AppendEntries = 4
	Committal = 5
	ClientRequest = 6

class MessageDirection(object):
	Request = 0
	Response = 1	

#---------------------------------REQUEST VOTE ACKNOWLEDGEMENT--------------------------------------------------

class REQUESTVOTE_ACK(object): 
	def __init__(self, term=None, vote_granted=None, message=None):
		if (message is not None):
			self.un_jsonify(message)
		else:
			self._term = term
			self._vote_granted = vote_granted

	@property
	def term(self):
		return self._term

	@property
	def vote_granted(self):
		return self._vote_granted

	def un_jsonify(self, message):
		self._term = 			message['term']     
		self._vote_granted =	message['vote_granted']     

	def jsonify(self):
		return {
			'term':      		self._term,
			'vote_granted': 	self._vote_granted
		}


class STATE_RESULT(object):
	def __init__(self, term=None, success=None, message=None):
		if (message is not None):
			self.un_jsonify(message)
		else:
			self._term = term
			self._success = success

	@property
	def term(self):
		return self._term

	@property
	def success(self):
		return self._success

	def un_jsonify(self, message):
		self._term = 	message['term']     
		self._success =	message['success']     

	def jsonify(self):
		return {
			'term':      	self._term,
			'success':      self._success
		}

class BaseMessage(object):

	def __init__(self, type_, term, sender, receiver, direction, results):
		self._timestamp = int(time.time())
		self._type = type_
		self._term = term				
		self._sender = sender
		self._receiver = receiver
		self._direction = direction
		self._results = results

	@property
	def timestamp(self):
		return self._timestamp

	@property
	def type(self):
		return self._type

	@property
	def term(self):
		return self._term

	@property
	def sender(self):
		return self._sender

	@property
	def receiver(self):
		return self._receiver

	@property
	def direction(self):
		return self._direction

	@property
	def results(self):
		return self._results

	def un_jsonify(self, message):
		self._type = 			message['type']     
		self._term = 			message['term']     
		self._timestamp = 		message['timestamp']
		self._sender = 			message['sender']
		self._receiver = 		message['receiver'] 
		self._direction = 		message['direction']
		if (self._type == MessageType.RequestVotes):
			self._results = REQUESTVOTE_ACK(message=message['results'])
		else:
			self._results = STATE_RESULT(message=message['results'])

	def jsonify(self):
		return {
			'type':      	self._type,
			'term':      	self._term,
			'timestamp': 	self._timestamp,
			'sender':    	self._sender,
			'receiver':  	self._receiver,
			'direction': 	self._direction,
			'results': 		self._results.jsonify()
		}

#--------------------------------------REQUESTVOTE_RPC/START ELECTION---------------------------------

class REQUEST_VOTE(BaseMessage):
	def __init__(self, type_=None, term=None, sender=None, receiver=None, direction=None, results=None, candidate_id=None, last_log_index=None, last_log_term=None, message=None):
		if (message is not None):
			self.un_jsonify(message)
		else:
			if (results is None):
				results = REQUESTVOTE_ACK()
			BaseMessage.__init__(self, type_, term, sender, receiver, direction, results)
			self._candidate_id = candidate_id
			self._last_log_index = last_log_index
			self._last_log_term = last_log_term
		
	@property
	def candidate_id(self):
		return self._candidate_id

	@property
	def last_log_index(self):
		return self._last_log_index

	@property
	def last_log_term(self):
		return self._last_log_term

	def un_jsonify(self, message):
		BaseMessage.un_jsonify(self, message)
		self._candidate_id = 	message['candidate_id']
		self._last_log_index = 	message['last_log_index']
		self._last_log_term = 	message['last_log_term']

	def jsonify(self):
		message = BaseMessage.jsonify(self)
		message.update({
			'candidate_id': 	self._candidate_id,
			'last_log_index': 	self._last_log_index,
			'last_log_term': 	self._last_log_term
		})
		return message

#---------------------------------------APPENDENTRY_RPC AND HEARTBEATS-----------------------------------------

class APPENDEntry_RPC(BaseMessage):
	def __init__(self, type_=None, term=None, sender=None, receiver=None, direction=None, results=None, leader_id=None, prev_log_index=None, prev_log_term=None, entries=None, leader_commit=None, message=None):
		if (message is not None):
			self.un_jsonify(message)
		else:
			if (results is None):
				results = STATE_RESULT()
			BaseMessage.__init__(self, type_, term, sender, receiver, direction, results)
			self._leader_id = leader_id
			self._prev_log_index = prev_log_index
			self._prev_log_term = prev_log_term
			self._entries = entries
			self._leader_commit = leader_commit

	@property
	def leader_id(self):
		return self._leader_id

	@property
	def prev_log_index(self):
		return self._prev_log_index

	@property
	def prev_log_term(self):
		return self._prev_log_term

	@property
	def entries(self):
		return self._entries

	@property
	def leader_commit(self):
		return self._leader_commit

	def un_jsonify(self, message):
		BaseMessage.un_jsonify(self, message)
		self._leader_id = 		message['leader_id']
		self._prev_log_index = 	message['prev_log_index']
		self._prev_log_term = 	message['prev_log_term']
		self._entries = 		message['entries']
		self._leader_commit = 	message['leader_commit']

	def jsonify(self):
		message = BaseMessage.jsonify(self)
		message.update({
			'leader_id': 		self._leader_id,
			'prev_log_index': 	self._prev_log_index,
			'prev_log_term': 	self._prev_log_term,
			'entries': 			self._entries,
			'leader_commit': 	self._leader_commit
		})
		return message

def parse_json_message(json_message):
	if json_message is None:
		return None
	elif json_message['type'] == MessageType.RequestVotes:
		return REQUEST_VOTE(message=json_message)
	else:
		return APPENDEntry_RPC(message=json_message)
#______________________________________________interface_____________________________________________

class Talker(multiprocessing.Process):
	def __init__(self, identity):
		super(Talker, self).__init__()
		self.address = identity['my_id']
		self.initial_backoff = 1.0
		self.operation_backoff = 0.0001
		self.messages = multiprocessing.Queue()
		self._ready_event = multiprocessing.Event()
		self._stop_event = multiprocessing.Event()

	def stop(self):
		self._stop_event.set()

	def run(self):
		context = zmq.Context()
		pub_socket = context.socket(zmq.PUB)
		while True:
			try:
				pub_socket.bind("tcp://%s" % self.address)
				break
			except zmq.ZMQError:
				time.sleep(0.1)
		time.sleep(self.initial_backoff)

		self._ready_event.set()

		while not self._stop_event.is_set():
			try:
				pub_socket.send_json(self.messages.get_nowait())
			except Empty:
				try:
					time.sleep(self.operation_backoff)
				except KeyboardInterrupt:
					break
			except KeyboardInterrupt:
				break
		
		pub_socket.unbind("tcp://%s" % self.address)
		pub_socket.close()

	def send_message(self, msg):
		self.messages.put(msg)
	
	def wait_until_ready(self):
		while not self._ready_event.is_set():
			time.sleep(0.1)
		return True

class Listener(multiprocessing.Process):
	def __init__(self, port_list, identity):
		super(Listener, self).__init__()
		self.address_list = port_list
		self.identity = identity
		self.initial_backoff = 1.0
		self.messages = multiprocessing.Queue()
		self._stop_event = multiprocessing.Event()

	def stop(self):
		self._stop_event.set()

	def run(self):
		context = zmq.Context()
		sub_sock = context.socket(zmq.SUB)
		sub_sock.setsockopt(zmq.SUBSCRIBE, b'')
		for a in self.address_list:
			sub_sock.connect("tcp://%s" % a)
		poller = zmq.Poller()
		poller.register(sub_sock, zmq.POLLIN)
		time.sleep(self.initial_backoff)

		while not self._stop_event.is_set():
			try:
				obj = dict(poller.poll(100))
				if sub_sock in obj and obj[sub_sock] == zmq.POLLIN:
					msg = sub_sock.recv_json()	
					if ((msg['receiver'] == self.identity['my_id']) or (msg['receiver'] is None)):
						self.messages.put(msg)
			except KeyboardInterrupt:
				break
		
		sub_sock.close()
	
	def get_message(self):
		try:
			return self.messages.get_nowait()
		except Empty:
			return None

#_____________________________________________raft_______________________________________________________

address_book_fname = 'address_book.json'
total_nodes = 1
local_ip = '127.0.0.1'
start_port = 5557

#----------------------------Convert node to follower----------------------------------------

class Convert_Follower(threading.Thread):
    def __init__(self, config, name, role='follower', verbose=True):
        threading.Thread.__init__(self) 
        
        self._terminate = False
        self.daemon = True
        self.verbose = verbose
        self.client_queue = Queue()
        self.client_lock = threading.Lock()

        if (isinstance(config, dict)):
            address_book = config
        else:
            address_book = self._load_config(config, name)
        self.all_ids = [address_book[a]['ip'] + ':' + address_book[a]['port'] for a in address_book if a != 'leader']
        self.my_id = address_book[name]['ip'] + ':' + address_book[name]['port']
        self.election_timeout = random.uniform(0.1, 0.1+0.05*len(self.all_ids)) 
        self.heartbeat_frequency = 0.01                                     
        self.resend_time = 2.0                                               
        self._name = name                                                   
        self.current_num_nodes = len(self.all_ids)                          
        self.current_role = role                                            
        self.leader_id = None                                               
        self.current_term = 1                                               
        self.voted_for = None                                                
        self.log = [{'term': 1, 'entry': 'Init Entry', 'id': -1}]           
        self.log_hash = {}
        self.commit_index = 0                                               
        self.last_applied_index = 0                                         
        self.last_applied_term = 1                                          
        self.next_index = [None for _ in range(self.current_num_nodes)]     
        self.match_index = [0 for _ in range(self.current_num_nodes)]       
        self.heard_from = [0 for _ in range(self.current_num_nodes)]         
        identity = {'my_id': self.my_id, 'my_name': name}
        self.listener = Listener(port_list=self.all_ids, identity=identity)
        self.listener.start()
        self.talker = Talker(identity=identity)
        self.talker.start()

    def stop(self):
        self.talker.stop()
        self.listener.stop()
        self._terminate = True

    @property
    def name(self):
        return self._name
        
    def client_request(self, value, id_num=-1):
        
        entry = {
            'term': self.current_term,
            'entry': value,
            'id': id_num
        }
        self.client_queue.put(entry)

    def check_committed_entry(self, id_num=None):
       
        if (id_num is None):
            with self.client_lock:
                return self.log[self.commit_index]['entry']
        with self.client_lock:
            return self.log_hash.get(id_num, None)

    def check_role(self):
        
        with self.client_lock:
            return self.current_role

    def pause(self):
        
        self._set_current_role('none')
        if (self.verbose):
            print(self._name + ': pausing...')
        
    def un_pause(self):
        
        if (self.check_role() == 'none'):
            self._set_current_role('follower')
            if (self.verbose):
                print(self._name + ': unpausing...')
        else:
            if (self.verbose):
                print(self._name + ': node was not paused, doing nothing')

    def run(self):

        time.sleep(self.listener.initial_backoff)

        try:
            while not self._terminate:
                if self.check_role() == 'leader':
                    self._leader()
                elif self.check_role() == 'follower':
                    self._follower()
                elif self.check_role() == 'candidate':
                    self._candidate()
                else:
                    time.sleep(1)
        except KeyboardInterrupt:
            self.stop()

    def _follower(self):
        
        most_recent_heartbeat = time.time()

        while ((not self._terminate) and (self.check_role() == 'follower')):
            incoming_message = self._get_message()
            if (incoming_message is not None):

                if (incoming_message.direction == MessageDirection.Request):

                    if (incoming_message.type == MessageType.RequestVotes):
                        if (incoming_message.term > self.current_term):
                            self._increment_term(incoming_message.term)
                        if ((self.voted_for is None) and (incoming_message.last_log_index >= self.last_applied_index) and (incoming_message.last_log_term >= self.last_applied_term)):
                            self._send_vote(incoming_message.sender)
                        else: 
                            self._send_vote(incoming_message.sender, False)
                        most_recent_heartbeat = time.time()
                    elif (incoming_message.type == MessageType.Heartbeat):
                        if (incoming_message.term > self.current_term):
                            self._increment_term(incoming_message.term)
                        self.leader_id = incoming_message.leader_id
                        most_recent_heartbeat = time.time()
                        if (self.leader_id):
                            client_request = self._get_client_request()
                            if (client_request is not None):
                                self._send_client_request(incoming_message.leader_id, client_request)
                    elif (incoming_message.type == MessageType.AppendEntries):
                        if (incoming_message.term < self.current_term):
                            self._send_acknowledge(incoming_message.leader_id, False)
                        elif (not self._verify_entry(incoming_message.prev_log_index, incoming_message.prev_log_term)):
                            self._send_acknowledge(incoming_message.leader_id, False)
                        else:
                            if (incoming_message.leader_commit > self.commit_index):
                                self._append_entry(incoming_message.entries, commit=True, prev_index=incoming_message.prev_log_index)
                            else:
                                self._append_entry(incoming_message.entries, commit=False, prev_index=incoming_message.prev_log_index)
                            self._send_acknowledge(incoming_message.leader_id, True)
                    elif (incoming_message.type == MessageType.Committal):
                        self._commit_entry(incoming_message.prev_log_index, incoming_message.prev_log_term)

        #-----------------------------------ELECTION TIMEOUT-------------------------------------------------

            if ((time.time() - most_recent_heartbeat) > (self.election_timeout)):
                self._set_current_role('candidate')
                return
        return

    def _candidate(self):
        
        if(self.verbose):
            print(self._name + ': became candidate')
        self._increment_term()
        self._send_request_vote()
        self._send_vote(self.my_id, True)
        votes_for_me = 0
        total_votes = 0
        time_election_going = time.time()

        while ((not self._terminate) and (self.check_role() == 'candidate')):
            incoming_message = self._get_message()
            if (incoming_message is not None):
                if (incoming_message.direction == MessageDirection.Response):
                    if (incoming_message.type == MessageType.RequestVotes):
                        if (incoming_message.results.vote_granted):
                            votes_for_me += 1
                        total_votes += 1
                        if ((votes_for_me > int(old_div(self.current_num_nodes, 2))) or (self.current_num_nodes == 1)):
                            self._set_current_role('leader')
                            return
                elif (incoming_message.direction == MessageDirection.Request):
                    if (incoming_message.type == MessageType.RequestVotes):
                        if (incoming_message.term > self.current_term):
                            self._increment_term(incoming_message.term)
                            self._send_vote(incoming_message.sender)
                            self._set_current_role('follower')
                            return
                    elif (incoming_message.type == MessageType.Heartbeat):
                        if (incoming_message.term >= self.current_term):
                            self._increment_term(incoming_message.term)
                            self.leader_id = incoming_message.leader_id
                            self._set_current_role('follower')
                            return
            if ((time.time() - time_election_going) > self.election_timeout):
                if(self.verbose):
                    print(self._name + ': election timed out')
                self._set_current_role('candidate')
                return
        
        return

    def _leader(self):
                
        if(self.verbose):
            print(self._name + ': became leader')
        self._send_heartbeat()
        most_recent_heartbeat = time.time()
        self.leader_id = self.my_id
        self.match_index = [self.commit_index for _ in range(self.current_num_nodes)]
        self.next_index = [None for _ in range(self.current_num_nodes)]
        self.heard_from = [time.time() for _ in range(self.current_num_nodes)]
        entry = {'term': self.current_term, 'entry': 'Leader Entry', 'id': -1}
        self._broadcast_append_entries(entry)

        while ((not self._terminate) and (self.check_role() == 'leader')):
            if ((time.time() - most_recent_heartbeat) > self.heartbeat_frequency):
                self._send_heartbeat()
                most_recent_heartbeat = time.time()
                if (self.verbose):
                    pass
                    #print(self._name + ': sent heartbeat')
                    #print(self._name + ': max committed index: ' + str(self.commit_index))
            for node, index in enumerate(self.next_index):
                if ((index is not None) and ((time.time() - self.heard_from[node]) > self.resend_time)):
                    self._send_append_entries(index - 1, self.log[index - 1]['term'], self.log[index], self.all_ids[node])
                    self.heard_from[node] = time.time()
            incoming_message = self._get_message()
            if (incoming_message is not None):
                if (incoming_message.direction == MessageDirection.Response):
                    if (incoming_message.type == MessageType.Acknowledge):
                        sender_index = self._get_node_index(incoming_message.sender)
                        self.heard_from[sender_index] = time.time()
                        if (self.next_index[sender_index] is not None):
                            if (incoming_message.results.success):
                                self.match_index[sender_index] = self.next_index[sender_index]
                                self.next_index[sender_index] += 1
                            else:
                                if (self.next_index[sender_index] != 1):
                                    self.next_index[sender_index] -= 1
                            if self.next_index[sender_index] > self._log_max_index():
                                self.next_index[sender_index] = None
                            else:
                                next_index = self.next_index[sender_index]
                                self._send_append_entries(next_index - 1, self.log[next_index - 1]['term'], self.log[next_index], incoming_message.sender)
                            
                            if (self.verbose):
                                print(self._name + ": updated standing is " + str(self.match_index) + " my index: " + str(self._log_max_index()))

                            log_lengths = [int(i) for i in self.match_index if (i is not None)]
                            log_lengths.sort(reverse=True)
                            max_committable_index = 0
                            for index in log_lengths:
                                replicated_on = sum([1 if index <= i else 0 for i in log_lengths])
                                if (replicated_on >= (int(old_div(self.current_num_nodes, 2)) + 1)):
                                    max_committable_index = index
                            if (max_committable_index > self.commit_index):
                                    self._broadcast_commmit_entries(max_committable_index)
                    elif (incoming_message.type == MessageType.ClientRequest):
                        client_request = incoming_message.entries
                        self._broadcast_append_entries(client_request)
                elif (incoming_message.direction == MessageDirection.Request):
                    if (incoming_message.type == MessageType.RequestVotes):
                        if (incoming_message.term > self.current_term):
                            self._increment_term(incoming_message.term)
                            self._send_vote(incoming_message.sender)
                            self._set_current_role('follower')

                            if(self.verbose):
                                print(self._name + ': saw higher term, demoting')
                            return

            client_request = self._get_client_request()
            if (client_request is not None):
                self._broadcast_append_entries(client_request)

        return

    def _send_message(self, message):
        
        self.talker.send_message(message.jsonify())

    def _get_message(self):
        
        return parse_json_message(self.listener.get_message())

    def _load_config(self, config, name):
        with open(config, 'r') as infile:
            data = json.load(infile)
        return data

    def _get_client_request(self):
        
        try:
            return self.client_queue.get(block=False)
        except Empty:
            return None
    
    def _set_current_role(self, role):
        
        with self.client_lock:
            self.current_role = role

    def _get_node_index(self, node_address):
       
        return self.all_ids.index(node_address)

    def _log_max_index(self):
        
        return len(self.log) - 1

    def _increment_term(self, term=None):
       
        self.voted_for = None
        if (term is None):
            self.current_term = self.current_term + 1
        else:
            self.current_term = term

    def _verify_entry(self, prev_index, prev_term):
        
        
        if (len(self.log) <= prev_index):
            return False
        if (self.log[prev_index]['term'] == prev_term):
            return True
        return False

    def _append_entry(self, entry, commit=False, prev_index=None):
        if (prev_index is None):
            prev_index = len(self.log) - 1
        else:
            self.log = self.log[:prev_index+1]
        prev_term = self.log[-1]['term']
        with self.client_lock:
            self.log.append(entry)
            self.log_hash[entry['id']] = entry
        if (commit):
            self._commit_entry(prev_index, entry['term'])

        return prev_index, prev_term

    def _commit_entry(self, index, term):
      
        self.last_applied_index = index
        self.last_applied_term = term
        with self.client_lock:
            self.commit_index = index

    def _broadcast_append_entries(self, entry):
        prev_index, prev_term = self._append_entry(entry, commit=False)
        for node, index in enumerate(self.next_index):
            if (index is None):
                self._send_append_entries(prev_index, prev_term, entry, self.all_ids[node])
                self.next_index[node] = self._log_max_index()
        self.next_index[self._get_node_index(self.my_id)] =  None
        self.match_index[self._get_node_index(self.my_id)] = self._log_max_index()

    def _broadcast_commmit_entries(self, index):
        self._commit_entry(index, self.log[index]['term'])
        for node, index in enumerate(self.match_index):
            if (index >= index):
                self._send_committal(index, self.all_ids[node])

    def _send_request_vote(self, receiver=None):
        message = REQUEST_VOTE(
            type_ =   MessageType.RequestVotes, 
            term =   self.current_term, 
            sender = self.my_id,
            receiver = receiver, 
            direction = MessageDirection.Request, 
            candidate_id = self.my_id, 
            last_log_index = self.last_applied_index,
            last_log_term = self.last_applied_term
        )
        self._send_message(message)

    def _send_vote(self, candidate, vote_granted=True):
        message = REQUEST_VOTE(
            type_ =   MessageType.RequestVotes, 
            term =   self.current_term,
            sender = self.my_id,
            receiver = candidate, 
            direction = MessageDirection.Response, 
            candidate_id = candidate, 
            last_log_index = self.last_applied_index,
            last_log_term = self.last_applied_term,
            results = REQUESTVOTE_ACK(
                term = self.current_term,
                vote_granted = vote_granted
            )
        )
        self._send_message(message)
        self.voted_for = candidate

    def _send_heartbeat(self):
        message = APPENDEntry_RPC(
            type_ = MessageType.Heartbeat,
            term = self.current_term,
            sender = self.my_id,
            receiver = None,
            direction = MessageDirection.Request,
            leader_id = self.my_id,
            prev_log_index = None,
            prev_log_term = None,
            entries = None,
            leader_commit = self.commit_index
        )
        self._send_message(message)

    def _send_append_entries(self, index, term, entries, receiver=None):
        message = APPENDEntry_RPC(
            type_ = MessageType.AppendEntries,
            term = self.current_term,
            sender = self.my_id,
            receiver = receiver,
            direction = MessageDirection.Request,
            leader_id = self.my_id,
            prev_log_index = index,
            prev_log_term = term,
            entries = entries,
            leader_commit = self.commit_index
        )
        self._send_message(message)
    
    def _send_committal(self, index, receiver=None):
        message = APPENDEntry_RPC(
            type_ = MessageType.Committal,
            term = self.current_term,
            sender = self.my_id,
            receiver = receiver,
            direction = MessageDirection.Request,
            leader_id = self.my_id,
            prev_log_index = self.last_applied_index,
            prev_log_term = self.last_applied_term,
            entries = None,
            leader_commit = self.commit_index
        )
        self._send_message(message)

    def _send_acknowledge(self, receiver, success, entry=None):
        message = APPENDEntry_RPC(
            type_ = MessageType.Acknowledge,
            term = self.current_term,
            sender = self.my_id,
            receiver = receiver,
            direction = MessageDirection.Response,
            leader_id =self.leader_id ,
            prev_log_index = self.last_applied_index,
            prev_log_term = self.last_applied_term,
            entries = entry,
            leader_commit = self.commit_index, 
            results = STATE_RESULT(
                term = self.current_term,
                success = success
            ) 
        )
        self._send_message(message)

    def _send_client_request(self, receiver, entry):
        message = APPENDEntry_RPC(
            type_ = MessageType.ClientRequest,
            term = self.current_term,
            sender = self.my_id,
            receiver = receiver,
            direction = MessageDirection.Response,
            leader_id =self.leader_id ,
            prev_log_index = self.last_applied_index,
            prev_log_term = self.last_applied_term,
            entries = entry,
            leader_commit = self.commit_index
        )
        self._send_message(message)

if __name__ == '__main__':
    d = {"node1": {"ip": "192.168.0.1", "port": "5000"}, 
         "node2": {"ip": "192.168.0.1", "port": "5001"}, 
         "node3": {"ip": "192.168.0.1", "port": "5002"},
        #  "node4": {"ip": "192.168.0.1", "port": "5003"},
        #  "node5": {"ip": "192.168.0.1", "port": "5004"}
        }
        
    with open(address_book_fname, 'w') as outfile:
        json.dump(d, outfile)

    s0 = Convert_Follower(address_book_fname, 'node1', 'follower')
    s1 = Convert_Follower(address_book_fname, 'node2', 'follower')
    s2 = Convert_Follower(address_book_fname, 'node3', 'follower')
    #s3 = Convert_Follower(address_book_fname, 'node4', 'follower')
    #s4 = Convert_Follower(address_book_fname, 'node5', 'follower')
   
    s0.start()
    s1.start()
    s2.start()
    #s3.start()
    #s4.start()

#-----------------------------------------CONTROLLER SHUTDOWN--------------------------------------------------
    def shutdown():
        
        try:
            while True:
                pass
        except KeyboardInterrupt:
            s0.stop()
            s1.stop()
            s2.stop()
            #s3.stop()
            #s4.stop()